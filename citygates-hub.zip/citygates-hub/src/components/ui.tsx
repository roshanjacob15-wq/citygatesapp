"use client";
import { cx, initials } from "@/lib/util";
import type { Person } from "@/lib/types";

export function Avatar({ p, size = 36 }: { p?: Pick<Person, "full_name" | "avatar_url"> | null; size?: number }) {
  return (
    <span className="avatar" style={{ width: size, height: size, fontSize: size * 0.38 }} aria-hidden>
      {p?.avatar_url ? <img src={p.avatar_url} alt="" /> : initials(p?.full_name)}
    </span>
  );
}
export function PageHead({ title, kicker, children }: { title: string; kicker?: string; children?: React.ReactNode }) {
  return (
    <header className="page-head">
      <div>
        {kicker && <p className="kicker">{kicker}</p>}
        <h1>{title}</h1>
      </div>
      {children && <div className="head-actions">{children}</div>}
    </header>
  );
}
export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="empty">{children}</div>;
}
export function Badge({ tone = "plain", children }: { tone?: "plain" | "gold" | "green" | "red" | "ink"; children: React.ReactNode }) {
  return <span className={cx("badge", `badge-${tone}`)}>{children}</span>;
}
export function Tabs({ value, onChange, items }: { value: string; onChange: (v: any) => void; items: { id: string; label: string }[] }) {
  return (
    <div className="tabs" role="tablist">
      {items.map((i) => (
        <button key={i.id} role="tab" aria-selected={value === i.id} className={cx("tab", value === i.id && "on")} onClick={() => onChange(i.id)}>
          {i.label}
        </button>
      ))}
    </div>
  );
}
export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="modal-wrap" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-label={title}>
        <div className="modal-head">
          <h2>{title}</h2>
          <button className="icon-btn" onClick={onClose} aria-label="Close">×</button>
        </div>
        {children}
      </div>
    </div>
  );
}
export function PersonSelect({ people, value, onChange, placeholder = "Unassigned" }: { people: Person[]; value?: string | null; onChange: (id: string | null) => void; placeholder?: string }) {
  return (
    <select className="field" value={value ?? ""} onChange={(e) => onChange(e.target.value || null)}>
      <option value="">{placeholder}</option>
      {people.map((p) => <option key={p.id} value={p.id}>{p.full_name}</option>)}
    </select>
  );
}
const ICONS: Record<string, string> = {
  home: "M3 11l9-8 9 8v9a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1z",
  rota: "M4 5h16v15H4zM4 10h16M9 3v4M15 3v4",
  chat: "M4 5h16v11H9l-5 4z",
  board: "M12 3l2 5 5 .5-4 3.5 1.3 5L12 14.5 7.700 17l1.300-5L5 8.500 10 8z",
  more: "M5 6h14M5 12h14M5 18h14",
  services: "M5 4h14M5 9h14M5 14h9M5 19h6",
  teams: "M9 11a3 3 0 100-6 3 3 0 000 6zM3 20c0-3.500 2.700-6 6-6s6 2.500 6 6M17 11a2.500 2.500 0 100-5M18 14c2 .5 3 2.300 3 5",
  people: "M12 12a4 4 0 100-8 4 4 0 000 8zM4 21c0-4 3.500-7 8-7s8 3 8 7",
  events: "M12 2v4M4 8h16M5 5h14a1 1 0 011 1v14a1 1 0 01-1 1H5a1 1 0 01-1-1V6a1 1 0 011-1zM8 13h3",
  checkin: "M5 12l4 4 10-10",
  plus: "M12 5v14M5 12h14",
  send: "M4 12l16-8-6 16-3-7z",
  pin: "M9 3h6l-1 6 3 3H7l3-3zM12 12v9",
};
export function Icon({ name, size = 22 }: { name: string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d={ICONS[name] || ""} />
    </svg>
  );
}
