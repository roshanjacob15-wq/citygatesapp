"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useSession } from "@/lib/session";
import { DEMO } from "@/lib/db";
import { Avatar, Icon } from "./ui";
import { cx } from "@/lib/util";

const MAIN = [
  { href: "/", label: "Home", icon: "home" },
  { href: "/rota", label: "Rota", icon: "rota" },
  { href: "/chat", label: "Chat", icon: "chat" },
  { href: "/board", label: "Board", icon: "board" },
];
const MORE = [
  { href: "/services", label: "Services", icon: "services" },
  { href: "/teams", label: "Teams", icon: "teams" },
  { href: "/people", label: "People", icon: "people" },
  { href: "/events", label: "Events", icon: "events" },
  { href: "/checkin", label: "Check-in", icon: "checkin", leader: true },
];

export default function Shell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const s = useSession();
  const [more, setMore] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    const h = (e: any) => { setMsg(e.detail); setTimeout(() => setMsg(null), 3200); };
    window.addEventListener("cg-toast", h);
    return () => window.removeEventListener("cg-toast", h);
  }, []);
  useEffect(() => setMore(false), [path]);
  useEffect(() => {
    if (s.ready && !s.me && path !== "/login") router.replace("/login");
  }, [s.ready, s.me, path, router]);

  if (path === "/login") return <>{children}</>;
  if (!s.ready || !s.me) return <div className="boot"><span className="mark">CG</span></div>;

  const more_items = MORE.filter((i) => !i.leader || s.isLeader);
  const active = (h: string) => (h === "/" ? path === "/" : path.startsWith(h));
  const nav = [...MAIN, ...more_items];

  return (
    <div className="shell">
      <aside className="side">
        <Link href="/" className="brand"><span className="mark">CG</span><span><b>CityGates</b><i>Hub</i></span></Link>
        <nav>
          {nav.map((i) => (
            <Link key={i.href} href={i.href} className={cx("nav-link", active(i.href) && "on")}>
              <Icon name={i.icon} size={20} />{i.label}
            </Link>
          ))}
        </nav>
        <div className="side-foot">
          {DEMO && (
            <div className="demo-box">
              <span className="kicker">Demo mode</span>
              <label className="sr" htmlFor="who">View as</label>
              <select id="who" className="field dark" value={s.me.id} onChange={(e) => s.switchDemoUser(e.target.value)}>
                {s.people.map((p) => <option key={p.id} value={p.id}>{p.full_name} ({p.role})</option>)}
              </select>
              <button className="link-btn" onClick={s.resetDemoData}>Reset sample data</button>
            </div>
          )}
          <Link href={`/people/${s.me.id}`} className="me-card">
            <Avatar p={s.me} size={34} />
            <span><b>{s.me.full_name}</b><i>{s.me.role}</i></span>
          </Link>
          {!DEMO && <button className="link-btn" onClick={s.signOut}>Sign out</button>}
        </div>
      </aside>

      <header className="topbar">
        <Link href="/" className="brand sm"><span className="mark">CG</span><b>CityGates Hub</b></Link>
        <Link href={`/people/${s.me.id}`} aria-label="My profile"><Avatar p={s.me} size={32} /></Link>
      </header>

      <main className="main">{children}</main>

      <nav className="tabbar" aria-label="Primary">
        {MAIN.map((i) => (
          <Link key={i.href} href={i.href} className={cx("tab-link", active(i.href) && "on")}><Icon name={i.icon} />{i.label}</Link>
        ))}
        <button className={cx("tab-link", more && "on")} onClick={() => setMore(!more)}><Icon name="more" />More</button>
      </nav>

      {more && (
        <div className="sheet-wrap" onClick={() => setMore(false)}>
          <div className="sheet" onClick={(e) => e.stopPropagation()}>
            <div className="sheet-grid">
              {more_items.map((i) => (
                <Link key={i.href} href={i.href} className="sheet-item"><Icon name={i.icon} />{i.label}</Link>
              ))}
            </div>
            {DEMO && (
              <div className="demo-box light">
                <span className="kicker">Demo mode · view as</span>
                <select className="field" value={s.me.id} onChange={(e) => { s.switchDemoUser(e.target.value); setMore(false); }}>
                  {s.people.map((p) => <option key={p.id} value={p.id}>{p.full_name} ({p.role})</option>)}
                </select>
                <button className="link-btn" onClick={s.resetDemoData}>Reset sample data</button>
              </div>
            )}
            {!DEMO && <button className="link-btn" onClick={s.signOut}>Sign out</button>}
          </div>
        </div>
      )}
      {msg && <div className="toast" role="status">{msg}</div>}
    </div>
  );
}
