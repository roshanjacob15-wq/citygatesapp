"use client";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { db } from "@/lib/db";
import { useSession, useRows, write } from "@/lib/session";
import { Empty, Modal, PageHead, Icon } from "./ui";
import { cx } from "@/lib/util";
import type { Chat, ChatMember, Message } from "@/lib/types";

export default function ChatShell({ activeId, children }: { activeId?: string; children?: React.ReactNode }) {
  const { me, isLeader, isAdmin, people } = useSession();
  const chats = useRows<Chat>("chats");
  const members = useRows<ChatMember>("chat_members");
  const msgs = useRows<Message>("messages", ["created_at", true]);
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [picked, setPicked] = useState<string[]>([]);
  if (!me) return null;

  const mine = chats.rows.filter((c) => isAdmin || members.rows.some((m) => m.chat_id === c.id && m.person_id === me.id));
  const last = (id: string) => [...msgs.rows].reverse().find((m) => m.chat_id === id);

  async function create(e: React.FormEvent) {
    e.preventDefault();
    const r = await write<any>(db.from("chats").insert({ name, team_id: null, created_by: me!.id }).select().single());
    const chat = Array.isArray(r) ? r[0] : r;
    if (!chat?.id) return;
    await write(db.from("chat_members").insert([...new Set([me!.id, ...picked])].map((pid) => ({ chat_id: chat.id, person_id: pid }))));
    setOpen(false); setName(""); setPicked([]); chats.reload(); members.reload(); router.push(`/chat/${chat.id}`);
  }

  return (
    <>
      <PageHead kicker="Talk" title="Chat">{isLeader && <button className="btn gold" onClick={() => setOpen(true)}><Icon name="plus" size={16} />New group</button>}</PageHead>
      <div className={cx("chat-layout", activeId && "thread-active")}>
        <div className="card chat-list chat-list-col" style={{ padding: 8 }}>
          {mine.length === 0 && <Empty>No chats yet.</Empty>}
          {mine.map((c) => {
            const l = last(c.id);
            return (
              <Link key={c.id} href={`/chat/${c.id}`} className={cx(activeId === c.id && "on")}>
                <span className="mark" style={{ width: 38, height: 38, fontSize: "0.9rem", borderColor: "var(--gold-deep)", color: "var(--gold-deep)" }}>{c.name.slice(0, 1)}</span>
                <span className="grow"><b>{c.name}</b><p className="small muted" style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{l ? l.body : "No messages yet"}</p></span>
              </Link>
            );
          })}
        </div>
        <div className="chat-main">{children ?? <div className="empty chat-hint">Pick a chat to start talking.</div>}</div>
      </div>
      {open && (
        <Modal title="New group chat" onClose={() => setOpen(false)}>
          <form className="stack" onSubmit={create}>
            <label className="lbl">Group name<input className="field" required value={name} onChange={(e) => setName(e.target.value)} /></label>
            <div className="stack-sm" style={{ maxHeight: 240, overflow: "auto" }}>
              {people.filter((p) => p.id !== me.id).map((p) => (
                <label key={p.id} className="row small"><input type="checkbox" checked={picked.includes(p.id)} onChange={() => setPicked(picked.includes(p.id) ? picked.filter((x) => x !== p.id) : [...picked, p.id])} />{p.full_name}</label>
              ))}
            </div>
            <button className="btn gold" type="submit">Create group</button>
          </form>
        </Modal>
      )}
    </>
  );
}
export type { Message };
