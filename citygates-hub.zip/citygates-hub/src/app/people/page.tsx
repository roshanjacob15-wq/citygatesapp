"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import { db } from "@/lib/db";
import { useSession, write } from "@/lib/session";
import { Avatar, Badge, Empty, Modal, PageHead } from "@/components/ui";
import { cap, cx } from "@/lib/util";
import { STAGES, SUGGESTED_TAGS, type Stage } from "@/lib/types";

export default function People() {
  const { people, teams, teamMembers, isLeader, isAdmin, refresh } = useSession();
  const [q, setQ] = useState("");
  const [stage, setStage] = useState<Stage | "all">("all");
  const [tag, setTag] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ full_name: "", email: "", phone: "", stage: "visitor" as Stage, role: "member" });

  const allTags = useMemo(() => [...new Set([...SUGGESTED_TAGS, ...people.flatMap((p) => p.tags || [])])], [people]);
  const shown = people.filter((p) =>
    (stage === "all" || p.stage === stage) && (!tag || (p.tags || []).includes(tag)) &&
    (!q || (p.full_name + " " + (p.email || "")).toLowerCase().includes(q.toLowerCase())));

  async function add(e: React.FormEvent) {
    e.preventDefault();
    await write(db.from("profiles").insert({ ...f, email: f.email || null, tags: [], bio: "" }), "Person added. They can sign in with that email.");
    setOpen(false); setF({ full_name: "", email: "", phone: "", stage: "visitor", role: "member" }); refresh();
  }

  return (
    <>
      <PageHead kicker="Community" title="People">{isLeader && <button className="btn gold" onClick={() => setOpen(true)}>Add person</button>}</PageHead>
      <div className="stack">
        <input className="field" type="search" placeholder="Search by name or email" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search people" />
        <div className="tagrow">
          <button className={cx("chip", stage === "all" && "on")} onClick={() => setStage("all")}>All · {people.length}</button>
          {STAGES.map((s) => <button key={s} className={cx("chip", stage === s && "on")} onClick={() => setStage(s)}>{cap(s)} · {people.filter((p) => p.stage === s).length}</button>)}
        </div>
        <div className="tagrow">
          {allTags.map((t) => <button key={t} className={cx("chip", tag === t && "on")} onClick={() => setTag(tag === t ? null : t)}>{t}</button>)}
        </div>
        {shown.length === 0 ? <Empty>No one matches those filters.</Empty> : (
          <div className="card">
            {shown.map((p) => (
              <Link href={`/people/${p.id}`} className="item" key={p.id}>
                <Avatar p={p} size={40} />
                <div className="grow">
                  <b>{p.full_name}</b>
                  <p className="small muted">{teamMembers.filter((m) => m.person_id === p.id).map((m) => teams.find((t) => t.id === m.team_id)?.name).filter(Boolean).join(", ") || "Not on a team"}</p>
                  <div className="tagrow" style={{ marginTop: 4 }}>{(p.tags || []).map((t) => <span className="chip" key={t} style={{ padding: "1px 8px", fontSize: "0.72rem" }}>{t}</span>)}</div>
                </div>
                <div className="stack-sm" style={{ justifyItems: "end" }}>
                  <Badge tone={p.stage === "leader" ? "ink" : p.stage === "member" ? "gold" : "plain"}>{p.stage}</Badge>
                  {p.role !== "member" && <Badge tone="green">{p.role}</Badge>}
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
      {open && (
        <Modal title="Add person" onClose={() => setOpen(false)}>
          <form className="stack" onSubmit={add}>
            <label className="lbl">Full name<input className="field" required value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} /></label>
            <label className="lbl">Email (they sign in with this)<input className="field" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></label>
            <label className="lbl">Phone<input className="field" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></label>
            <label className="lbl">Stage<select className="field" value={f.stage} onChange={(e) => setF({ ...f, stage: e.target.value as Stage })}>{STAGES.map((s) => <option key={s}>{s}</option>)}</select></label>
            {isAdmin && <label className="lbl">Access level<select className="field" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}><option>member</option><option>leader</option><option>admin</option></select></label>}
            <button className="btn gold" type="submit">Add</button>
          </form>
        </Modal>
      )}
    </>
  );
}
