"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { db } from "@/lib/db";
import { useSession, useRows, write } from "@/lib/session";
import { Avatar, Badge, Empty, PageHead } from "@/components/ui";
import { cap, cx, fmtDate, fmtTime, isFuture } from "@/lib/util";
import { statusLabel, statusTone } from "@/lib/rota";
import { STAGES, SUGGESTED_TAGS, type Person, type Service, type Slot, type Unavail } from "@/lib/types";

export default function Profile() {
  const { id } = useParams<{ id: string }>();
  const { me, people, teams, teamMembers, isLeader, isAdmin, refresh } = useSession();
  const slots = useRows<Slot>("rota_slots");
  const services = useRows<Service>("services");
  const unavail = useRows<Unavail>("unavailability", ["day", true]);
  const p = people.find((x) => x.id === id);
  const [form, setForm] = useState<Partial<Person>>({});
  const [tagDraft, setTagDraft] = useState("");
  const [day, setDay] = useState(""); const [why, setWhy] = useState("");
  useEffect(() => { if (p) setForm(p); }, [p?.id, p?.full_name, p?.stage, p?.role, (p?.tags || []).join()]);
  if (!p || !me) return <Empty>Person not found.</Empty>;

  const isMe = me.id === p.id;
  const canEdit = isMe || isLeader;
  const tags = form.tags || [];
  const teamsOf = teamMembers.filter((m) => m.person_id === p.id);
  const serving = slots.rows.filter((s) => s.person_id === p.id).map((s) => ({ s, sv: services.rows.find((x) => x.id === s.service_id) }))
    .filter((x) => x.sv && isFuture(x.sv.starts_at)).sort((a, b) => a.sv!.starts_at.localeCompare(b.sv!.starts_at));
  const blocked = unavail.rows.filter((u) => u.person_id === p.id && u.day >= new Date().toISOString().slice(0, 10));

  async function save(patch: Partial<Person>) {
    const next = { ...form, ...patch };
    setForm(next);
    await write(db.from("profiles").update(patch).eq("id", p!.id));
    refresh();
  }
  const toggleTag = (t: string) => save({ tags: tags.includes(t) ? tags.filter((x) => x !== t) : [...tags, t] });
  async function addBlock(e: React.FormEvent) {
    e.preventDefault();
    if (!day) return;
    await write(db.from("unavailability").insert({ person_id: p!.id, day, reason: why }), "Date blocked. Leaders will see it when building the rota.");
    setDay(""); setWhy(""); unavail.reload();
  }

  return (
    <>
      <PageHead kicker={isMe ? "My profile" : "Profile"} title={p.full_name} />
      <div className="grid-2" style={{ alignItems: "start" }}>
        <section className="card stack">
          <div className="row"><Avatar p={p} size={64} />
            <div><div className="row wrap"><Badge tone={p.stage === "leader" ? "ink" : "gold"}>{p.stage}</Badge>{p.role !== "member" && <Badge tone="green">{p.role}</Badge>}</div>
              <p className="small muted" style={{ marginTop: 6 }}>Joined {p.created_at ? fmtDate(p.created_at) : "recently"}</p></div></div>
          {canEdit ? (<>
            <label className="lbl">Full name<input className="field" value={form.full_name || ""} onChange={(e) => setForm({ ...form, full_name: e.target.value })} onBlur={() => form.full_name && form.full_name !== p.full_name && save({ full_name: form.full_name })} /></label>
            <label className="lbl">Email<input className="field" type="email" value={form.email || ""} onChange={(e) => setForm({ ...form, email: e.target.value })} onBlur={() => (form.email || null) !== (p.email || null) && save({ email: form.email || null })} /></label>
            <label className="lbl">Phone<input className="field" value={form.phone || ""} onChange={(e) => setForm({ ...form, phone: e.target.value })} onBlur={() => (form.phone || "") !== (p.phone || "") && save({ phone: form.phone })} /></label>
            <label className="lbl">About me<textarea className="field" value={form.bio || ""} onChange={(e) => setForm({ ...form, bio: e.target.value })} onBlur={() => (form.bio || "") !== (p.bio || "") && save({ bio: form.bio })} /></label>
          </>) : (<>
            <p>{p.bio || <span className="muted">No bio yet.</span>}</p>
            {p.email && <p className="small"><span className="muted">Email</span> {p.email}</p>}
            {p.phone && <p className="small"><span className="muted">Phone</span> {p.phone}</p>}
          </>)}
        </section>

        <div className="stack">
          <section className="card stack-sm">
            <h2>Category</h2>
            {isLeader ? (<>
              <label className="lbl">Journey stage<select className="field" value={p.stage} onChange={(e) => save({ stage: e.target.value as any })}>{STAGES.map((s) => <option key={s} value={s}>{cap(s)}</option>)}</select></label>
              {isAdmin && !isMe && <label className="lbl">Access level<select className="field" value={p.role} onChange={(e) => save({ role: e.target.value as any })}><option value="member">Member</option><option value="leader">Leader</option><option value="admin">Admin</option></select></label>}
            </>) : <p className="small muted">Stage: {cap(p.stage)}</p>}
            <div className="tagrow">
              {(isLeader ? [...new Set([...SUGGESTED_TAGS, ...tags])] : tags).map((t) => (
                isLeader ? <button key={t} className={cx("chip", tags.includes(t) && "on")} onClick={() => toggleTag(t)}>{t}</button> : <span className="chip" key={t}>{t}</span>
              ))}
              {!isLeader && tags.length === 0 && <span className="small muted">No tags</span>}
            </div>
            {isLeader && <form className="row" onSubmit={(e) => { e.preventDefault(); if (tagDraft.trim()) { toggleTag(tagDraft.trim()); setTagDraft(""); } }}>
              <input className="field" placeholder="Add a custom tag" value={tagDraft} onChange={(e) => setTagDraft(e.target.value)} /><button className="btn sm" type="submit">Add</button></form>}
          </section>

          <section className="card">
            <h2 style={{ marginBottom: 10 }}>Teams</h2>
            {teamsOf.length === 0 ? <p className="small muted">Not on a team yet.</p> : teamsOf.map((m) => {
              const t = teams.find((x) => x.id === m.team_id);
              return t ? <div className="item" key={t.id}><span className="dot" style={{ background: t.colour }} /><b className="grow">{t.name}</b><span className="small muted">{m.position}</span></div> : null;
            })}
          </section>

          <section className="card">
            <h2 style={{ marginBottom: 10 }}>Serving</h2>
            {serving.length === 0 ? <p className="small muted">Nothing scheduled.</p> : serving.slice(0, 5).map(({ s, sv }) => (
              <div className="item" key={s.id}><div className="grow"><b>{s.role_name}</b><p className="small muted">{fmtDate(sv!.starts_at)} · {fmtTime(sv!.starts_at)}</p></div><Badge tone={statusTone(s.status)}>{statusLabel(s.status)}</Badge></div>
            ))}
          </section>

          {canEdit && (
            <section className="card stack-sm">
              <h2>Dates I can't serve</h2>
              {blocked.map((u) => <div className="item" key={u.id}><b className="grow">{fmtDate(u.day)}</b><span className="small muted">{u.reason}</span>
                <button className="icon-btn" aria-label="Remove" onClick={() => write(db.from("unavailability").delete().eq("id", u.id)).then(unavail.reload)}>×</button></div>)}
              <form className="row wrap" onSubmit={addBlock}>
                <input className="field grow" type="date" value={day} onChange={(e) => setDay(e.target.value)} aria-label="Date" />
                <input className="field grow" placeholder="Reason (optional)" value={why} onChange={(e) => setWhy(e.target.value)} />
                <button className="btn sm" type="submit">Block</button>
              </form>
            </section>
          )}
        </div>
      </div>
    </>
  );
}
