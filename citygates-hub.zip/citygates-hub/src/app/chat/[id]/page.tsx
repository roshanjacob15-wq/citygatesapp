"use client";
import Link from "next/link";
import { useEffect, useRef, useState, useCallback } from "react";
import { useParams } from "next/navigation";
import { db } from "@/lib/db";
import { useSession, write } from "@/lib/session";
import ChatShell from "@/components/ChatShell";
import { Avatar, Icon } from "@/components/ui";
import { cx, fmtTime, fmtDate } from "@/lib/util";
import type { Chat, ChatMember, Message } from "@/lib/types";

function Thread({ id }: { id: string }) {
  const { me, person, people, isLeader } = useSession();
  const [msgs, setMsgs] = useState<Message[]>([]);
  const [chat, setChat] = useState<Chat | null>(null);
  const [mem, setMem] = useState<ChatMember[]>([]);
  const [text, setText] = useState("");
  const end = useRef<HTMLDivElement>(null);

  const load = useCallback(async () => {
    const [m, c, cm] = await Promise.all([
      db.from("messages").select("*").eq("chat_id", id).order("created_at", { ascending: true }),
      db.from("chats").select("*").eq("id", id).maybeSingle(),
      db.from("chat_members").select("*").eq("chat_id", id),
    ]);
    setMsgs(m.data ?? []); setChat(c.data ?? null); setMem(cm.data ?? []);
  }, [id]);
  useEffect(() => {
    load();
    const ch = db.channel(`thread-${id}-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "messages" }, () => load()).subscribe();
    return () => { db.removeChannel(ch); };
  }, [id, load]);
  useEffect(() => { end.current?.scrollIntoView({ block: "end" }); }, [msgs.length]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const body = text.trim();
    if (!body || !me) return;
    setText("");
    await write(db.from("messages").insert({ chat_id: id, sender_id: me.id, body }));
    load();
  }
  if (!chat || !me) return <div className="empty">Chat not found, or you're not a member.</div>;

  let lastDay = "";
  return (
    <div className="thread">
      <div className="card row between" style={{ borderRadius: "12px 12px 0 0", borderBottom: 0 }}>
        <div className="row"><Link href="/chat" className="chat-back small" aria-label="Back to chats">←</Link><div><b>{chat.name}</b><p className="small muted">{mem.map((m) => person(m.person_id)?.full_name.split(" ")[0]).filter(Boolean).slice(0, 6).join(", ")}{mem.length > 6 ? ` +${mem.length - 6}` : ""}</p></div></div>
      </div>
      <div className="msgs">
        {msgs.length === 0 && <p className="muted small" style={{ margin: "auto" }}>Say hello 👋</p>}
        {msgs.map((m) => {
          const mine = m.sender_id === me.id;
          const sender = person(m.sender_id);
          const day = m.created_at.slice(0, 10);
          const sep = day !== lastDay ? <p key={`d${m.id}`} className="kicker" style={{ textAlign: "center", margin: "6px 0" }}>{fmtDate(m.created_at)}</p> : null;
          lastDay = day;
          return (
            <div key={m.id} style={{ display: "contents" }}>
              {sep}
              <div className={cx("msg", mine && "mine")}>
                {!mine && <Avatar p={sender} size={28} />}
                <div className="bubble"><small>{mine ? "You" : sender?.full_name} · {fmtTime(m.created_at)}</small>{m.body}</div>
              </div>
            </div>
          );
        })}
        <div ref={end} />
      </div>
      <form className="composer" onSubmit={send}>
        <input className="field" placeholder="Write a message" value={text} onChange={(e) => setText(e.target.value)} aria-label="Message" />
        <button className="btn gold" type="submit" aria-label="Send"><Icon name="send" size={18} /></button>
      </form>
    </div>
  );
}

export default function ChatPage() {
  const { id } = useParams<{ id: string }>();
  return <ChatShell activeId={id}><Thread id={id} /></ChatShell>;
}
