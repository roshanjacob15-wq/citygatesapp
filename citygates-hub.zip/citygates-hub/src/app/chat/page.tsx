"use client";
import ChatShell from "@/components/ChatShell";
export default function ChatHome() { return <ChatShell />; }
