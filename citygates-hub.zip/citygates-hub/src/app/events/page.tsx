"use client";
import { useState } from "react";
import { db } from "@/lib/db";
import { useSession, useRows, write } from "@/lib/session";
import { Avatar, Badge, Empty, Modal, PageHead } from "@/components/ui";
import { fmtLongDate, fmtTime, isFuture } from "@/lib/util";
import type { EventRow, Signup } from "@/lib/types";

export default function Events() {
  const { me, person, isLeader } = useSession();
  const events = useRows<EventRow>("events", ["starts_at", true]);
  const signups = useRows<Signup>("event_signups");
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ title: "", description: "", location: "", when: "", capacity: "" });
  if (!me) return null;

  async function create(e: React.FormEvent) {
    e.preventDefault();
    await write(db.from("events").insert({ title: f.title, description: f.description, location: f.location, starts_at: new Date(f.when).toISOString(), capacity: f.capacity ? +f.capacity : null }), "Event created.");
    setOpen(false); setF({ title: "", description: "", location: "", when: "", capacity: "" }); events.reload();
  }
  async function toggle(ev: EventRow, going: boolean) {
    if (going) await write(db.from("event_signups").delete().eq("event_id", ev.id).eq("person_id", me!.id));
    else await write(db.from("event_signups").insert({ event_id: ev.id, person_id: me!.id }), "You're signed up.");
    signups.reload();
  }
  const del = async (id: string) => { if (confirm("Delete this event?")) { await write(db.from("events").delete().eq("id", id)); events.reload(); } };
  const list = events.rows.filter((e) => isFuture(e.starts_at));

  return (
    <>
      <PageHead kicker="Gatherings" title="Events">{isLeader && <button className="btn gold" onClick={() => setOpen(true)}>New event</button>}</PageHead>
      {list.length === 0 ? <Empty>No upcoming events.</Empty> : (
        <div className="stack">
          {list.map((ev) => {
            const going = signups.rows.filter((s) => s.event_id === ev.id);
            const am = going.some((s) => s.person_id === me.id);
            const full = !!ev.capacity && going.length >= ev.capacity && !am;
            return (
              <article className="card stack-sm" key={ev.id}>
                <div className="row wrap between">
                  <div className="row">
                    <div className="date-chip"><b>{new Date(ev.starts_at).getDate()}</b><span>{new Date(ev.starts_at).toLocaleDateString("en-GB", { month: "short" })}</span></div>
                    <div><h2>{ev.title}</h2><p className="small muted">{fmtLongDate(ev.starts_at)} · {fmtTime(ev.starts_at)}{ev.location ? ` · ${ev.location}` : ""}</p></div>
                  </div>
                  <Badge tone={full ? "red" : "plain"}>{going.length}{ev.capacity ? ` / ${ev.capacity}` : ""} going</Badge>
                </div>
                {ev.description && <p>{ev.description}</p>}
                <div className="row between wrap">
                  <div className="row" style={{ gap: 0 }}>{going.slice(0, 8).map((s) => <span key={s.person_id} style={{ marginRight: -6 }}><Avatar p={person(s.person_id)} size={28} /></span>)}</div>
                  <div className="row">
                    {isLeader && <button className="btn danger sm" onClick={() => del(ev.id)}>Delete</button>}
                    <button className={am ? "btn ghost" : "btn gold"} disabled={full} onClick={() => toggle(ev, am)}>{am ? "Cancel my place" : full ? "Full" : "I'm going"}</button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
      {open && (
        <Modal title="New event" onClose={() => setOpen(false)}>
          <form className="stack" onSubmit={create}>
            <label className="lbl">Title<input className="field" required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></label>
            <label className="lbl">Date and time<input className="field" type="datetime-local" required value={f.when} onChange={(e) => setF({ ...f, when: e.target.value })} /></label>
            <label className="lbl">Location<input className="field" value={f.location} onChange={(e) => setF({ ...f, location: e.target.value })} /></label>
            <label className="lbl">Capacity (leave blank for no limit)<input className="field" type="number" min={1} value={f.capacity} onChange={(e) => setF({ ...f, capacity: e.target.value })} /></label>
            <label className="lbl">Description<textarea className="field" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></label>
            <button className="btn gold" type="submit">Create event</button>
          </form>
        </Modal>
      )}
    </>
  );
}
