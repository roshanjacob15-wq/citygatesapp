"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { auth, DEMO } from "@/lib/db";
import { useSession } from "@/lib/session";

export default function Login() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();
  const s = useSession();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    const { error } = await auth.signInWithOtp({ email, options: { emailRedirectTo: window.location.origin } });
    if (error) setErr(error.message); else setSent(true);
  }

  return (
    <div className="login">
      <div className="login-card">
        <div className="stack-sm">
          <span className="mark">CG</span>
          <p className="kicker" style={{ color: "var(--gold)" }}>CityGates Church Dubai</p>
          <h1>Serve well, <em>together.</em></h1>
          <p style={{ color: "#c9c1b2" }}>Rotas, teams, chat and news in one place.</p>
        </div>
        {DEMO ? (
          <div className="stack-sm">
            <p className="small" style={{ color: "#c9c1b2" }}>Demo mode is on, so there is no sign-in. Add your Supabase keys to switch on real accounts.</p>
            <button className="btn gold" onClick={() => { s.refresh().then(() => router.replace("/")); }}>Enter the demo</button>
          </div>
        ) : sent ? (
          <p>Check your inbox. We have sent a sign-in link to <b>{email}</b>.</p>
        ) : (
          <form className="stack-sm" onSubmit={submit}>
            <label className="sr" htmlFor="em">Email</label>
            <input id="em" className="field" type="email" required placeholder="you@email.com" value={email} onChange={(e) => setEmail(e.target.value)} />
            <button className="btn gold" type="submit">Email me a sign-in link</button>
            {err && <p className="warn" style={{ color: "#ff8a80" }}>{err}</p>}
            <p className="small" style={{ color: "#a59d8f" }}>Use the email your church admin has on file for you.</p>
          </form>
        )}
      </div>
    </div>
  );
}
