"use client";
import Link from "next/link";
import { useSession, useRows } from "@/lib/session";
import { respond, statusLabel, statusTone } from "@/lib/rota";
import { Badge, Empty } from "@/components/ui";
import { fmtDate, fmtTime, isFuture } from "@/lib/util";
import type { EventRow, Post, Service, Slot } from "@/lib/types";

export default function Home() {
  const { me, teams, isLeader, person } = useSession();
  const slots = useRows<Slot>("rota_slots");
  const services = useRows<Service>("services", ["starts_at", true]);
  const posts = useRows<Post>("posts", ["created_at", false]);
  const events = useRows<EventRow>("events", ["starts_at", true]);
  if (!me) return null;

  const svc = (id: string) => services.rows.find((s) => s.id === id);
  const mine = slots.rows
    .filter((s) => s.person_id === me.id && svc(s.service_id) && isFuture(svc(s.service_id)!.starts_at))
    .sort((a, b) => svc(a.service_id)!.starts_at.localeCompare(svc(b.service_id)!.starts_at));
  const upcoming = services.rows.filter((s) => isFuture(s.starts_at));
  const upIds = new Set(upcoming.map((s) => s.id));
  const unfilled = slots.rows.filter((s) => !s.person_id && upIds.has(s.service_id)).length;
  const swaps = slots.rows.filter((s) => s.status === "swap_requested" && upIds.has(s.service_id)).length;
  const declined = slots.rows.filter((s) => s.status === "declined" && upIds.has(s.service_id)).length;
  const pinned = [...posts.rows].sort((a, b) => Number(b.pinned) - Number(a.pinned)).slice(0, 3);
  const evs = events.rows.filter((e) => isFuture(e.starts_at)).slice(0, 3);
  const hour = new Date().getHours();
  const greet = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const next = mine[0];

  return (
    <div className="stack">
      <section className="card ink">
        <p className="kicker">{next ? "You're next serving" : "This week"}</p>
        <h1 style={{ margin: "10px 0 6px" }}>{greet}, {me.full_name.split(" ")[0]}.</h1>
        <p style={{ color: "#c9c1b2" }}>
          {next
            ? <>{next.role_name} with {teams.find((t) => t.id === next.team_id)?.name} on <b style={{ color: "var(--cream)" }}>{fmtDate(svc(next.service_id)!.starts_at)}</b> at {fmtTime(svc(next.service_id)!.starts_at)}.</>
            : "You have nothing on the rota yet. Check the open slots to see where you can help."}
        </p>
      </section>

      {isLeader && (unfilled + swaps + declined > 0) && (
        <Link href="/rota" className="card" style={{ borderColor: "var(--gold)" }}>
          <div className="row between wrap">
            <div><p className="kicker">Needs attention</p>
              <p style={{ marginTop: 6 }}><b>{unfilled}</b> unfilled · <b>{swaps}</b> swap {swaps === 1 ? "request" : "requests"}{declined > 0 && <> · <b>{declined}</b> declined</>}</p></div>
            <span className="btn sm gold">Open rota</span>
          </div>
        </Link>
      )}

      <div className="grid-2">
        <section className="card">
          <div className="card-title"><h2>Your serving</h2><Link href="/rota" className="small muted">All →</Link></div>
          {mine.length === 0 ? <Empty>Nothing coming up.</Empty> : mine.slice(0, 4).map((s) => (
            <div className="item" key={s.id}>
              <div className="date-chip"><b>{new Date(svc(s.service_id)!.starts_at).getDate()}</b><span>{new Date(svc(s.service_id)!.starts_at).toLocaleDateString("en-GB", { month: "short" })}</span></div>
              <div className="grow">
                <b>{s.role_name}</b>
                <p className="small muted">{teams.find((t) => t.id === s.team_id)?.name} · {fmtTime(svc(s.service_id)!.starts_at)}</p>
              </div>
              {s.status === "pending"
                ? <div className="row"><button className="btn sm gold" onClick={() => respond(s.id, "accepted").then(slots.reload)}>Accept</button><button className="btn sm ghost" onClick={() => respond(s.id, "declined").then(slots.reload)}>Decline</button></div>
                : <Badge tone={statusTone(s.status)}>{statusLabel(s.status)}</Badge>}
            </div>
          ))}
        </section>

        <section className="card">
          <div className="card-title"><h2>Coming up</h2><Link href="/events" className="small muted">Events →</Link></div>
          {evs.length === 0 ? <Empty>No events yet.</Empty> : evs.map((e) => (
            <div className="item" key={e.id}>
              <div className="date-chip"><b>{new Date(e.starts_at).getDate()}</b><span>{new Date(e.starts_at).toLocaleDateString("en-GB", { month: "short" })}</span></div>
              <div className="grow"><b>{e.title}</b><p className="small muted">{fmtTime(e.starts_at)}{e.location ? ` · ${e.location}` : ""}</p></div>
            </div>
          ))}
        </section>
      </div>

      <section className="card">
        <div className="card-title"><h2>Bulletin</h2><Link href="/board" className="small muted">Board →</Link></div>
        {pinned.length === 0 ? <Empty>Nothing posted yet.</Empty> : pinned.map((p) => (
          <div className="item" key={p.id} style={{ alignItems: "flex-start" }}>
            <div className="grow">
              <div className="row wrap">{p.pinned && <Badge tone="gold">Pinned</Badge>}<b>{p.title}</b></div>
              <p className="small muted" style={{ marginTop: 4 }}>{(p.body || "").slice(0, 140)}{(p.body || "").length > 140 ? "…" : ""}</p>
              <p className="small muted">{person(p.author_id)?.full_name}</p>
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}
