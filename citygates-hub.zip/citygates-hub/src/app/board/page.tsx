"use client";
import { useState } from "react";
import { db } from "@/lib/db";
import { useSession, useRows, write } from "@/lib/session";
import { Avatar, Badge, Empty, Modal, PageHead } from "@/components/ui";
import { cx, fmtAgo } from "@/lib/util";
import { POST_CATEGORIES, type Post } from "@/lib/types";

export default function Board() {
  const { me, person, isLeader } = useSession();
  const posts = useRows<Post>("posts", ["created_at", false]);
  const [cat, setCat] = useState("all");
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ title: "", body: "", category: "announcement", pinned: false });
  if (!me) return null;

  const label = (id: string) => POST_CATEGORIES.find((c) => c.id === id)?.label ?? id;
  const shown = [...posts.rows].filter((p) => cat === "all" || p.category === cat).sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.created_at.localeCompare(a.created_at));

  async function create(e: React.FormEvent) {
    e.preventDefault();
    await write(db.from("posts").insert({ ...f, pinned: isLeader && f.pinned, author_id: me!.id }), "Posted to the board.");
    setOpen(false); setF({ title: "", body: "", category: "announcement", pinned: false }); posts.reload();
  }
  const pin = async (p: Post) => { await write(db.from("posts").update({ pinned: !p.pinned }).eq("id", p.id)); posts.reload(); };
  const del = async (p: Post) => { if (confirm("Delete this post?")) { await write(db.from("posts").delete().eq("id", p.id)); posts.reload(); } };

  return (
    <>
      <PageHead kicker="Community" title="Bulletin board"><button className="btn gold" onClick={() => setOpen(true)}>New post</button></PageHead>
      <div className="tagrow" style={{ marginBottom: 16 }}>
        <button className={cx("chip", cat === "all" && "on")} onClick={() => setCat("all")}>All</button>
        {POST_CATEGORIES.map((c) => <button key={c.id} className={cx("chip", cat === c.id && "on")} onClick={() => setCat(c.id)}>{c.label}</button>)}
      </div>
      {shown.length === 0 ? <Empty>Nothing here yet. Be the first to post.</Empty> : (
        <div className="stack">
          {shown.map((p) => {
            const a = person(p.author_id);
            return (
              <article key={p.id} className={cx("card post stack-sm", p.pinned && "pinned")}>
                <div className="row wrap">{p.pinned && <Badge tone="gold">Pinned</Badge>}<Badge>{label(p.category)}</Badge></div>
                <h2>{p.title}</h2>
                {p.body && <p>{p.body}</p>}
                <div className="row between wrap">
                  <div className="row"><Avatar p={a} size={26} /><span className="small muted">{a?.full_name} · {fmtAgo(p.created_at)}</span></div>
                  <div className="row">
                    {isLeader && <button className="btn ghost sm" onClick={() => pin(p)}>{p.pinned ? "Unpin" : "Pin"}</button>}
                    {(isLeader || p.author_id === me.id) && <button className="btn danger sm" onClick={() => del(p)}>Delete</button>}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
      {open && (
        <Modal title="New post" onClose={() => setOpen(false)}>
          <form className="stack" onSubmit={create}>
            <label className="lbl">Title<input className="field" required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></label>
            <label className="lbl">Category<select className="field" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{POST_CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}</select></label>
            <label className="lbl">Details<textarea className="field" value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} /></label>
            {isLeader && <label className="row small"><input type="checkbox" checked={f.pinned} onChange={(e) => setF({ ...f, pinned: e.target.checked })} />Pin to the top</label>}
            <button className="btn gold" type="submit">Post</button>
          </form>
        </Modal>
      )}
    </>
  );
}
