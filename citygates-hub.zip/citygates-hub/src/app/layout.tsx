import type { Metadata, Viewport } from "next";
import "./globals.css";
import { SessionProvider } from "@/lib/session";
import Shell from "@/components/Shell";

export const metadata: Metadata = {
  title: "CityGates Hub",
  description: "Rotas, teams, chat and community for CityGates Church Dubai.",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#1a1714" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-GB">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=DM+Mono:wght@400;500&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet" />
      </head>
      <body>
        <SessionProvider><Shell>{children}</Shell></SessionProvider>
      </body>
    </html>
  );
}
