"use client";
import Link from "next/link";
import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { db } from "@/lib/db";
import { useSession, useRows, write } from "@/lib/session";
import { Avatar, Badge, Empty, PageHead } from "@/components/ui";
import type { Chat } from "@/lib/types";

export default function TeamDetail() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { teams, teamMembers, people, person, isLeader, isAdmin, refresh } = useSession();
  const chats = useRows<Chat>("chats");
  const [add, setAdd] = useState({ person: "", position: "" });
  const team = teams.find((t) => t.id === id);
  if (!team) return <Empty>Team not found.</Empty>;
  const members = teamMembers.filter((m) => m.team_id === id);
  const chat = chats.rows.find((c) => c.team_id === id);
  const candidates = people.filter((p) => !members.some((m) => m.person_id === p.id));

  async function addMember(e: React.FormEvent) {
    e.preventDefault();
    if (!add.person) return;
    await write(db.from("team_members").insert({ team_id: id, person_id: add.person, position: add.position }));
    if (chat) await write(db.from("chat_members").upsert({ chat_id: chat.id, person_id: add.person }, { onConflict: "chat_id,person_id" }));
    setAdd({ person: "", position: "" }); refresh();
  }
  async function remove(pid: string) {
    await write(db.from("team_members").delete().eq("team_id", id).eq("person_id", pid));
    if (chat) await write(db.from("chat_members").delete().eq("chat_id", chat.id).eq("person_id", pid));
    refresh();
  }
  async function setLeader(pid: string | null) { await write(db.from("teams").update({ leader_id: pid }).eq("id", id)); refresh(); }
  async function del() {
    if (!confirm(`Delete ${team!.name}? Its rota slots and chat will go too.`)) return;
    await write(db.from("teams").delete().eq("id", id)); refresh(); router.push("/teams");
  }

  return (
    <>
      <PageHead kicker="Team" title={team.name}>
        {chat && <Link className="btn ghost sm" href={`/chat/${chat.id}`}>Team chat</Link>}
        {isAdmin && <button className="btn danger sm" onClick={del}>Delete team</button>}
      </PageHead>
      <p className="muted" style={{ marginBottom: 16 }}>{team.description}</p>
      <section className="card">
        <div className="card-title"><h2>Members</h2><span className="small muted">{members.length}</span></div>
        {members.length === 0 && <Empty>No one has been added yet.</Empty>}
        {members.map((m) => {
          const p = person(m.person_id);
          if (!p) return null;
          return (
            <div className="item" key={m.person_id}>
              <Avatar p={p} />
              <Link href={`/people/${p.id}`} className="grow"><b>{p.full_name}</b><p className="small muted">{m.position || "Team member"}</p></Link>
              {team.leader_id === p.id && <Badge tone="gold">Leader</Badge>}
              {isLeader && (<>
                {team.leader_id !== p.id && <button className="btn ghost sm" onClick={() => setLeader(p.id)}>Make leader</button>}
                <button className="icon-btn" aria-label={`Remove ${p.full_name}`} onClick={() => remove(p.id)}>×</button>
              </>)}
            </div>
          );
        })}
        {isLeader && (
          <form className="row wrap" style={{ marginTop: 16 }} onSubmit={addMember}>
            <select className="field grow" value={add.person} onChange={(e) => setAdd({ ...add, person: e.target.value })} aria-label="Person to add">
              <option value="">Add a person…</option>
              {candidates.map((p) => <option key={p.id} value={p.id}>{p.full_name}</option>)}
            </select>
            <input className="field grow" placeholder="Position, e.g. Vocals" value={add.position} onChange={(e) => setAdd({ ...add, position: e.target.value })} />
            <button className="btn sm" type="submit">Add</button>
          </form>
        )}
      </section>
    </>
  );
}
