"use client";
import Link from "next/link";
import { useState } from "react";
import { db } from "@/lib/db";
import { useSession, write } from "@/lib/session";
import { Empty, Modal, PageHead, Avatar } from "@/components/ui";

const COLOURS = ["#C9A96E", "#B23A2F", "#1A2E22", "#7A231D", "#3a342e", "#8a6a2b"];

export default function Teams() {
  const { teams, teamMembers, person, isAdmin, me, refresh } = useSession();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: "", description: "", colour: COLOURS[0] });

  async function create(e: React.FormEvent) {
    e.preventDefault();
    const t = await write<any>(db.from("teams").insert({ ...f, leader_id: null }).select().single(), "Team created.");
    const row = Array.isArray(t) ? t[0] : t;
    if (row?.id) {
      const c = await write<any>(db.from("chats").insert({ name: f.name, team_id: row.id, created_by: me?.id }).select().single());
      const chat = Array.isArray(c) ? c[0] : c;
      if (chat?.id && me) await write(db.from("chat_members").insert({ chat_id: chat.id, person_id: me.id }));
    }
    setOpen(false); setF({ name: "", description: "", colour: COLOURS[0] }); refresh();
  }
  return (
    <>
      <PageHead kicker="Serving" title="Teams">{isAdmin && <button className="btn gold" onClick={() => setOpen(true)}>New team</button>}</PageHead>
      {teams.length === 0 ? <Empty>No teams yet.{isAdmin ? " Create your first serving team to get started." : ""}</Empty> : (
        <div className="grid-2">
          {teams.map((t) => {
            const m = teamMembers.filter((x) => x.team_id === t.id);
            return (
              <Link href={`/teams/${t.id}`} className="card stack-sm" key={t.id} style={{ borderTop: `4px solid ${t.colour}` }}>
                <div className="row between"><h3>{t.name}</h3><span className="small muted">{m.length} {m.length === 1 ? "person" : "people"}</span></div>
                <p className="small muted">{t.description || "No description yet."}</p>
                <div className="row" style={{ gap: 0 }}>
                  {m.slice(0, 6).map((x) => <span key={x.person_id} style={{ marginRight: -6 }}><Avatar p={person(x.person_id)} size={30} /></span>)}
                  {t.leader_id && <span className="small muted" style={{ marginLeft: 16 }}>Led by {person(t.leader_id)?.full_name}</span>}
                </div>
              </Link>
            );
          })}
        </div>
      )}
      {open && (
        <Modal title="New serving team" onClose={() => setOpen(false)}>
          <form className="stack" onSubmit={create}>
            <label className="lbl">Name<input className="field" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></label>
            <label className="lbl">What does this team do?<textarea className="field" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></label>
            <div className="row wrap">{COLOURS.map((c) => (
              <button type="button" key={c} aria-label={`Colour ${c}`} onClick={() => setF({ ...f, colour: c })} className="dot" style={{ width: 28, height: 28, background: c, border: f.colour === c ? "3px solid var(--ink)" : "1px solid var(--line)" }} />
            ))}</div>
            <button className="btn gold" type="submit">Create team and chat</button>
          </form>
        </Modal>
      )}
    </>
  );
}
