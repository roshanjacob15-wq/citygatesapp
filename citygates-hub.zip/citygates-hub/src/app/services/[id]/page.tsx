"use client";
import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { db } from "@/lib/db";
import { useSession, useRows, write } from "@/lib/session";
import { Badge, Empty, PageHead, PersonSelect } from "@/components/ui";
import { fmtLongDate, fmtTime, cap } from "@/lib/util";
import { statusLabel, statusTone } from "@/lib/rota";
import { ITEM_KINDS, type Service, type ServiceItem, type Slot } from "@/lib/types";

export default function ServiceDetail() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { isLeader, people, teams, person } = useSession();
  const services = useRows<Service>("services");
  const items = useRows<ServiceItem>("service_items", ["sort", true]);
  const slots = useRows<Slot>("rota_slots");
  const [d, setD] = useState({ title: "", kind: "other", minutes: 5, owner: null as string | null });

  const s = services.rows.find((x) => x.id === id);
  if (!s) return services.loading ? null : <Empty>Service not found.</Empty>;
  const list = items.rows.filter((i) => i.service_id === id).sort((a, b) => a.sort - b.sort);
  const start = new Date(s.starts_at).getTime();
  let acc = 0;
  const timed = list.map((i) => { const t = new Date(start + acc * 60000).toISOString(); acc += i.minutes; return { ...i, t }; });

  async function add(e: React.FormEvent) {
    e.preventDefault();
    if (!d.title.trim()) return;
    await write(db.from("service_items").insert({ service_id: id, sort: list.length, title: d.title, kind: d.kind, minutes: d.minutes, owner_id: d.owner, notes: "" }));
    setD({ ...d, title: "" }); items.reload();
  }
  async function move(i: number, dir: -1 | 1) {
    const a = list[i], b = list[i + dir];
    if (!a || !b) return;
    await write(db.from("service_items").update({ sort: b.sort }).eq("id", a.id));
    await write(db.from("service_items").update({ sort: a.sort }).eq("id", b.id));
    items.reload();
  }
  async function del(itemId: string) { await write(db.from("service_items").delete().eq("id", itemId)); items.reload(); }
  async function setOwner(itemId: string, owner: string | null) { await write(db.from("service_items").update({ owner_id: owner }).eq("id", itemId)); items.reload(); }
  async function delService() {
    if (!confirm("Delete this service and its rota?")) return;
    await write(db.from("services").delete().eq("id", id)); router.push("/services");
  }
  const mySlots = slots.rows.filter((x) => x.service_id === id);

  return (
    <>
      <PageHead kicker={fmtLongDate(s.starts_at)} title={s.title}>
        <Badge tone="gold">{fmtTime(s.starts_at)}</Badge>
        {isLeader && <button className="btn danger sm" onClick={delService}>Delete</button>}
      </PageHead>
      {s.notes && <p className="card" style={{ marginBottom: 14 }}>{s.notes}</p>}
      <div className="grid-2" style={{ alignItems: "start" }}>
        <section className="card">
          <div className="card-title"><h2>Run sheet</h2><span className="small muted">{acc} min · ends {fmtTime(new Date(start + acc * 60000).toISOString())}</span></div>
          {timed.length === 0 && <Empty>No items yet.</Empty>}
          {timed.map((i, idx) => (
            <div className="runrow" key={i.id}>
              <span className="time">{fmtTime(i.t)}</span>
              <div>
                <b>{i.title}</b>
                <div className="row wrap small muted"><Badge>{cap(i.kind)}</Badge><span>{i.minutes} min</span>
                  {isLeader ? <div style={{ minWidth: 150 }}><PersonSelect people={people} value={i.owner_id} onChange={(v) => setOwner(i.id, v)} placeholder="Who leads?" /></div> : <span>{person(i.owner_id)?.full_name}</span>}
                </div>
              </div>
              {isLeader && (
                <div className="row">
                  <button className="icon-btn" aria-label="Move up" disabled={idx === 0} onClick={() => move(idx, -1)}>↑</button>
                  <button className="icon-btn" aria-label="Move down" disabled={idx === timed.length - 1} onClick={() => move(idx, 1)}>↓</button>
                  <button className="icon-btn" aria-label="Delete item" onClick={() => del(i.id)}>×</button>
                </div>
              )}
            </div>
          ))}
          {isLeader && (
            <form className="stack-sm" onSubmit={add} style={{ marginTop: 14 }}>
              <input className="field" placeholder="Item, e.g. Worship set" value={d.title} onChange={(e) => setD({ ...d, title: e.target.value })} />
              <div className="row">
                <select className="field" value={d.kind} onChange={(e) => setD({ ...d, kind: e.target.value })}>{ITEM_KINDS.map((k) => <option key={k}>{k}</option>)}</select>
                <input className="field" type="number" min={1} style={{ width: 90 }} value={d.minutes} onChange={(e) => setD({ ...d, minutes: +e.target.value })} aria-label="Minutes" />
                <button className="btn sm" type="submit">Add</button>
              </div>
            </form>
          )}
        </section>
        <section className="card">
          <div className="card-title"><h2>Who's serving</h2></div>
          {mySlots.length === 0 && <Empty>No rota built for this service.</Empty>}
          {teams.filter((t) => mySlots.some((x) => x.team_id === t.id)).map((t) => (
            <div key={t.id} style={{ marginBottom: 12 }}>
              <div className="row"><span className="dot" style={{ background: t.colour }} /><b>{t.name}</b></div>
              {mySlots.filter((x) => x.team_id === t.id).map((x) => (
                <div className="item" key={x.id} style={{ paddingLeft: 20 }}>
                  <span className="grow">{x.role_name}</span>
                  <span className="small">{person(x.person_id)?.full_name ?? <i className="muted">Open</i>}</span>
                  {x.person_id && <Badge tone={statusTone(x.status)}>{statusLabel(x.status)}</Badge>}
                </div>
              ))}
            </div>
          ))}
        </section>
      </div>
    </>
  );
}
