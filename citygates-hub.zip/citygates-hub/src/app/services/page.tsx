"use client";
import Link from "next/link";
import { useState } from "react";
import { db } from "@/lib/db";
import { useSession, useRows, write } from "@/lib/session";
import { Empty, Modal, PageHead, Badge } from "@/components/ui";
import { fmtLongDate, fmtTime, isFuture } from "@/lib/util";
import type { Service, Slot, ServiceItem } from "@/lib/types";

export default function Services() {
  const { isLeader } = useSession();
  const services = useRows<Service>("services", ["starts_at", true]);
  const slots = useRows<Slot>("rota_slots");
  const items = useRows<ServiceItem>("service_items");
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ title: "Sunday Gathering", when: "", weeks: 1, notes: "" });

  async function create(e: React.FormEvent) {
    e.preventDefault();
    if (!f.when) return;
    const rows = Array.from({ length: Math.max(1, Math.min(12, f.weeks)) }, (_, i) => {
      const d = new Date(f.when); d.setDate(d.getDate() + i * 7);
      return { title: f.title, starts_at: d.toISOString(), notes: f.notes };
    });
    await write(db.from("services").insert(rows), rows.length > 1 ? `${rows.length} services added.` : "Service added.");
    setOpen(false); services.reload();
  }
  const up = services.rows.filter((s) => isFuture(s.starts_at));
  const past = services.rows.filter((s) => !isFuture(s.starts_at)).reverse();

  const card = (s: Service) => {
    const ss = slots.rows.filter((x) => x.service_id === s.id);
    const filled = ss.filter((x) => x.person_id).length;
    const mins = items.rows.filter((i) => i.service_id === s.id).reduce((a, i) => a + i.minutes, 0);
    return (
      <Link href={`/services/${s.id}`} className="card row wrap between" key={s.id}>
        <div className="row">
          <div className="date-chip"><b>{new Date(s.starts_at).getDate()}</b><span>{new Date(s.starts_at).toLocaleDateString("en-GB", { month: "short" })}</span></div>
          <div><b>{s.title}</b><p className="small muted">{fmtLongDate(s.starts_at)} · {fmtTime(s.starts_at)}{mins ? ` · ${mins} min run sheet` : ""}</p></div>
        </div>
        <Badge tone={ss.length && filled === ss.length ? "green" : "plain"}>{ss.length ? `${filled}/${ss.length} serving` : "No rota"}</Badge>
      </Link>
    );
  };

  return (
    <>
      <PageHead kicker="Planning" title="Services">
        {isLeader && <button className="btn gold" onClick={() => setOpen(true)}>Add service</button>}
      </PageHead>
      <div className="stack">
        <div className="stack-sm">{up.length ? up.map(card) : <Empty>No upcoming services.</Empty>}</div>
        {past.length > 0 && (<><p className="kicker">Past</p><div className="stack-sm">{past.slice(0, 6).map(card)}</div></>)}
      </div>
      {open && (
        <Modal title="Add service" onClose={() => setOpen(false)}>
          <form className="stack" onSubmit={create}>
            <label className="lbl">Title<input className="field" required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></label>
            <label className="lbl">Date and time<input className="field" type="datetime-local" required value={f.when} onChange={(e) => setF({ ...f, when: e.target.value })} /></label>
            <label className="lbl">Repeat weekly for how many weeks?<input className="field" type="number" min={1} max={12} value={f.weeks} onChange={(e) => setF({ ...f, weeks: +e.target.value })} /></label>
            <label className="lbl">Notes<textarea className="field" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></label>
            <button className="btn gold" type="submit">Save</button>
          </form>
        </Modal>
      )}
    </>
  );
}
