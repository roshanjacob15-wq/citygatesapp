"use client";
import { useMemo, useState } from "react";
import { db } from "@/lib/db";
import { useSession, useRows, write } from "@/lib/session";
import { claim, respond, statusLabel, statusTone } from "@/lib/rota";
import { Avatar, Badge, Empty, PageHead, Tabs } from "@/components/ui";
import { fmtDate, fmtLongDate, fmtTime, isFuture, dayKey } from "@/lib/util";
import type { Service, Slot, Unavail } from "@/lib/types";

export default function RotaPage() {
  const { me, teams, teamMembers, people, person, isLeader } = useSession();
  const [tab, setTab] = useState<"mine" | "open" | "team">("mine");
  const slots = useRows<Slot>("rota_slots");
  const services = useRows<Service>("services", ["starts_at", true]);
  const unavail = useRows<Unavail>("unavailability");
  const [svcId, setSvcId] = useState<string>("");
  const [roleDraft, setRoleDraft] = useState<Record<string, string>>({});

  const upcoming = useMemo(() => services.rows.filter((s) => isFuture(s.starts_at)), [services.rows]);
  const svc = (id: string) => services.rows.find((s) => s.id === id);
  const current = upcoming.find((s) => s.id === svcId) ?? upcoming[0];
  if (!me) return null;

  const myTeams = new Set(teamMembers.filter((m) => m.person_id === me.id).map((m) => m.team_id));
  const mine = slots.rows.filter((s) => s.person_id === me.id && svc(s.service_id) && isFuture(svc(s.service_id)!.starts_at))
    .sort((a, b) => svc(a.service_id)!.starts_at.localeCompare(svc(b.service_id)!.starts_at));
  const open = slots.rows.filter((s) => svc(s.service_id) && isFuture(svc(s.service_id)!.starts_at) && (!s.person_id || s.status === "swap_requested") && s.person_id !== me.id && (isLeader || myTeams.has(s.team_id)))
    .sort((a, b) => svc(a.service_id)!.starts_at.localeCompare(svc(b.service_id)!.starts_at));

  const reloadAll = () => { slots.reload(); };

  function clashes(personId: string | null | undefined, slot: Slot) {
    if (!personId || !svc(slot.service_id)) return [];
    const out: string[] = [];
    const day = dayKey(svc(slot.service_id)!.starts_at);
    if (unavail.rows.some((u) => u.person_id === personId && u.day === day)) out.push("marked unavailable on this date");
    if (slots.rows.some((o) => o.id !== slot.id && o.service_id === slot.service_id && o.person_id === personId)) out.push("already serving in this service");
    return out;
  }
  async function assign(slot: Slot, personId: string | null) {
    await write(db.from("rota_slots").update({ person_id: personId, status: "pending" }).eq("id", slot.id));
    reloadAll();
  }
  async function addSlot(teamId: string) {
    const name = (roleDraft[teamId] || "").trim();
    if (!name || !current) return;
    await write(db.from("rota_slots").insert({ service_id: current.id, team_id: teamId, role_name: name, person_id: null, status: "pending" }));
    setRoleDraft({ ...roleDraft, [teamId]: "" }); reloadAll();
  }
  async function removeSlot(id: string) { await write(db.from("rota_slots").delete().eq("id", id)); reloadAll(); }
  async function copyPrevious() {
    if (!current) return;
    const idx = services.rows.findIndex((s) => s.id === current.id);
    const prev = services.rows.slice(0, idx).reverse().find((s) => slots.rows.some((x) => x.service_id === s.id));
    if (!prev) return write(Promise.resolve({ data: null, error: { message: "No earlier service has a rota to copy." } }));
    const rows = slots.rows.filter((x) => x.service_id === prev.id).map((x) => ({ service_id: current.id, team_id: x.team_id, role_name: x.role_name, person_id: x.person_id, status: "pending" }));
    await write(db.from("rota_slots").insert(rows), `Copied ${rows.length} slots from ${fmtDate(prev.starts_at)}.`);
    reloadAll();
  }

  const currentSlots = current ? slots.rows.filter((s) => s.service_id === current.id) : [];
  const teamIds = [...new Set([...currentSlots.map((s) => s.team_id), ...teams.map((t) => t.id)])];

  return (
    <>
      <PageHead kicker="Serving" title="Rota" />
      <Tabs value={tab} onChange={setTab} items={[
        { id: "mine", label: "My rota" }, { id: "open", label: `Open slots${open.length ? ` (${open.length})` : ""}` },
        ...(isLeader ? [{ id: "team" as const, label: "Build rota" }] : []),
      ]} />

      {tab === "mine" && (mine.length === 0 ? <Empty>You're not on the rota yet. Have a look at the open slots.</Empty> : (
        <div className="stack-sm">
          {mine.map((s) => {
            const sv = svc(s.service_id)!;
            return (
              <div className="card row wrap between" key={s.id}>
                <div className="row">
                  <div className="date-chip"><b>{new Date(sv.starts_at).getDate()}</b><span>{new Date(sv.starts_at).toLocaleDateString("en-GB", { month: "short" })}</span></div>
                  <div><b>{s.role_name}</b><p className="small muted">{teams.find((t) => t.id === s.team_id)?.name} · {sv.title} · {fmtTime(sv.starts_at)}</p></div>
                </div>
                <div className="row wrap">
                  <Badge tone={statusTone(s.status)}>{statusLabel(s.status)}</Badge>
                  {s.status !== "accepted" && <button className="btn sm gold" onClick={() => respond(s.id, "accepted").then(reloadAll)}>Accept</button>}
                  {s.status !== "swap_requested" && <button className="btn sm ghost" onClick={() => respond(s.id, "swap_requested").then(reloadAll)}>Ask for a swap</button>}
                  {s.status !== "declined" && <button className="btn sm danger" onClick={() => respond(s.id, "declined").then(reloadAll)}>Can't do it</button>}
                </div>
              </div>
            );
          })}
        </div>
      ))}

      {tab === "open" && (open.length === 0 ? <Empty>Every slot is covered. Thank you, team.</Empty> : (
        <div className="stack-sm">
          {open.map((s) => {
            const sv = svc(s.service_id)!;
            return (
              <div className="card row wrap between" key={s.id}>
                <div className="row">
                  <div className="date-chip"><b>{new Date(sv.starts_at).getDate()}</b><span>{new Date(sv.starts_at).toLocaleDateString("en-GB", { month: "short" })}</span></div>
                  <div>
                    <b>{s.role_name}</b>
                    <p className="small muted">{teams.find((t) => t.id === s.team_id)?.name} · {fmtDate(sv.starts_at)}{s.person_id ? ` · swap from ${person(s.person_id)?.full_name}` : " · unfilled"}</p>
                  </div>
                </div>
                <button className="btn sm gold" disabled={!isLeader && !myTeams.has(s.team_id)} onClick={() => claim(s.id, me.id).then(reloadAll)}>I'll take it</button>
              </div>
            );
          })}
        </div>
      ))}

      {tab === "team" && isLeader && (
        !current ? <Empty>Add a service first, under Services.</Empty> : (
          <div className="stack">
            <div className="row wrap">
              <select className="field" style={{ maxWidth: 320 }} value={current.id} onChange={(e) => setSvcId(e.target.value)} aria-label="Service">
                {upcoming.map((s) => <option key={s.id} value={s.id}>{fmtLongDate(s.starts_at)} · {s.title}</option>)}
              </select>
              <button className="btn ghost sm" onClick={copyPrevious}>Copy last rota</button>
            </div>
            {teamIds.map((tid) => {
              const team = teams.find((t) => t.id === tid);
              if (!team) return null;
              const rows = currentSlots.filter((s) => s.team_id === tid);
              const members = teamMembers.filter((m) => m.team_id === tid).map((m) => person(m.person_id)!).filter(Boolean);
              return (
                <section className="card" key={tid}>
                  <div className="card-title">
                    <div className="row"><span className="dot" style={{ background: team.colour }} /><h3>{team.name}</h3></div>
                    <span className="small muted">{rows.filter((r) => r.person_id).length}/{rows.length} filled</span>
                  </div>
                  {rows.length > 0 && (
                    <table className="rota-table">
                      <thead><tr><th>Role</th><th>Person</th><th>Status</th><th /></tr></thead>
                      <tbody>
                        {rows.map((r) => {
                          const warn = clashes(r.person_id, r);
                          return (
                            <tr key={r.id}>
                              <td><b>{r.role_name}</b></td>
                              <td style={{ minWidth: 150 }}>
                                <select className="field" value={r.person_id ?? ""} onChange={(e) => assign(r, e.target.value || null)} aria-label={`Person for ${r.role_name}`}>
                                  <option value="">Unassigned</option>
                                  {members.map((p) => <option key={p.id} value={p.id}>{p.full_name}</option>)}
                                  {r.person_id && !members.some((p) => p.id === r.person_id) && <option value={r.person_id}>{person(r.person_id)?.full_name}</option>}
                                </select>
                                {warn.length > 0 && <p className="warn">⚠ {person(r.person_id)?.full_name?.split(" ")[0]} is {warn.join(" and ")}</p>}
                              </td>
                              <td>{r.person_id ? <Badge tone={statusTone(r.status)}>{statusLabel(r.status)}</Badge> : <Badge>Open</Badge>}</td>
                              <td><button className="icon-btn" aria-label="Remove slot" onClick={() => removeSlot(r.id)}>×</button></td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  )}
                  <div className="row" style={{ marginTop: 12 }}>
                    <input className="field" placeholder="New role, e.g. Vocals" value={roleDraft[tid] || ""} onChange={(e) => setRoleDraft({ ...roleDraft, [tid]: e.target.value })} onKeyDown={(e) => e.key === "Enter" && addSlot(tid)} />
                    <button className="btn sm" onClick={() => addSlot(tid)}>Add</button>
                  </div>
                </section>
              );
            })}
            {teams.length === 0 && <Empty>Create your serving teams first, then build the rota.</Empty>}
          </div>
        )
      )}
    </>
  );
}
