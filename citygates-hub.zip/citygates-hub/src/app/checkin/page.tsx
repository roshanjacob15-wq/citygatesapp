"use client";
import { useMemo, useState } from "react";
import { db } from "@/lib/db";
import { useSession, useRows, write } from "@/lib/session";
import { Avatar, Badge, Empty, PageHead, Tabs } from "@/components/ui";
import { cx, fmtLongDate, fmtTime } from "@/lib/util";
import type { Attendance, Service } from "@/lib/types";

type Area = "main" | "kids" | "youth";

export default function CheckIn() {
  const { people, person, isLeader } = useSession();
  const services = useRows<Service>("services", ["starts_at", true]);
  const att = useRows<Attendance>("attendance");
  const [sid, setSid] = useState("");
  const [area, setArea] = useState<Area>("main");
  const [q, setQ] = useState("");
  const [guardian, setGuardian] = useState<Record<string, string>>({});

  const nearest = useMemo(() => {
    const now = Date.now();
    return [...services.rows].sort((a, b) => Math.abs(+new Date(a.starts_at) - now) - Math.abs(+new Date(b.starts_at) - now))[0];
  }, [services.rows]);
  const current = services.rows.find((s) => s.id === sid) ?? nearest;
  if (!isLeader) return <Empty>Check-in is for team leaders and admins.</Empty>;
  if (!current) return <Empty>Add a service to start checking people in.</Empty>;

  const here = att.rows.filter((a) => a.service_id === current.id);
  const count = (a: Area) => here.filter((x) => x.area === a).length;
  const shown = people.filter((p) => !q || p.full_name.toLowerCase().includes(q.toLowerCase()));

  async function checkIn(pid: string) {
    await write(db.from("attendance").insert({ service_id: current!.id, person_id: pid, area, guardian_id: area === "kids" ? guardian[pid] || null : null }));
    att.reload();
  }
  async function undo(id: string) { await write(db.from("attendance").delete().eq("id", id)); att.reload(); }

  return (
    <>
      <PageHead kicker="Sunday" title="Check-in">
        <select className="field" style={{ maxWidth: 300 }} aria-label="Service" value={current.id} onChange={(e) => setSid(e.target.value)}>
          {services.rows.map((s) => <option key={s.id} value={s.id}>{fmtLongDate(s.starts_at)} · {fmtTime(s.starts_at)}</option>)}
        </select>
      </PageHead>
      <div className="grid-3" style={{ marginBottom: 16 }}>
        {(["main", "kids", "youth"] as Area[]).map((a) => (
          <div className="card" key={a}><p className="kicker">{a === "main" ? "Main gathering" : a === "kids" ? "Kids" : "Youth"}</p><h1 style={{ marginTop: 8 }}>{count(a)}</h1></div>
        ))}
      </div>
      <Tabs value={area} onChange={setArea} items={[{ id: "main", label: "Main" }, { id: "kids", label: "Kids" }, { id: "youth", label: "Youth" }]} />
      <input className="field" type="search" placeholder="Search by name" value={q} onChange={(e) => setQ(e.target.value)} style={{ marginBottom: 14 }} aria-label="Search people" />
      <div className="card">
        {shown.map((p) => {
          const rec = here.find((x) => x.person_id === p.id);
          return (
            <div className="item" key={p.id}>
              <Avatar p={p} />
              <div className="grow"><b>{p.full_name}</b>{rec && <p className="small muted">In {rec.area}{rec.guardian_id ? ` · guardian ${person(rec.guardian_id)?.full_name}` : ""} at {fmtTime(rec.checked_in_at)}</p>}</div>
              {rec ? (<><Badge tone="green">Checked in</Badge><button className="btn ghost sm" onClick={() => undo(rec.id)}>Undo</button></>) : (<>
                {area === "kids" && (
                  <select className={cx("field")} style={{ maxWidth: 160 }} aria-label={`Guardian for ${p.full_name}`} value={guardian[p.id] || ""} onChange={(e) => setGuardian({ ...guardian, [p.id]: e.target.value })}>
                    <option value="">Guardian…</option>{people.filter((x) => x.id !== p.id).map((x) => <option key={x.id} value={x.id}>{x.full_name}</option>)}
                  </select>)}
                <button className="btn sm gold" onClick={() => checkIn(p.id)}>Check in</button>
              </>)}
            </div>
          );
        })}
      </div>
    </>
  );
}
