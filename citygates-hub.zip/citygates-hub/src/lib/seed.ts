// Sample data for DEMO MODE only. Names and details are invented.
const id = (p: string, n: number) => `${p}-${n}`;
function nextSunday(weeksAhead: number, h = 10, m = 0) {
  const d = new Date();
  d.setHours(h, m, 0, 0);
  const add = ((7 - d.getDay()) % 7) + weeksAhead * 7;
  d.setDate(d.getDate() + (add === 0 && new Date() > d ? 7 : add));
  return d;
}
const iso = (d: Date) => d.toISOString();
const ago = (mins: number) => new Date(Date.now() - mins * 60000).toISOString();

export function makeSeed() {
  const names: [string, string, string, string, string[]][] = [
    ["Abraham Jacob", "admin", "leader", "abraham@example.com", ["Young professional", "Creative"]],
    ["Grace Whitfield", "leader", "leader", "grace@example.com", ["Family", "Prayer partner"]],
    ["Daniel Okafor", "leader", "leader", "daniel@example.com", ["Young professional"]],
    ["Priya Menon", "member", "member", "priya@example.com", ["Student"]],
    ["Samuel Hart", "member", "member", "samuel@example.com", ["Family"]],
    ["Ruth Alvarez", "member", "member", "ruth@example.com", ["Young professional", "New to Dubai"]],
    ["Joshua Bell", "member", "regular", "joshua@example.com", ["Student"]],
    ["Naomi Clarke", "member", "member", "naomi@example.com", ["Family", "Home group host"]],
    ["Isaac Tan", "member", "regular", "isaac@example.com", ["Single"]],
    ["Esther Ndlovu", "member", "member", "esther@example.com", ["Young professional"]],
    ["Caleb Wright", "member", "visitor", "caleb@example.com", ["New to Dubai"]],
    ["Hannah Rossi", "member", "regular", "hannah@example.com", ["Student"]],
  ];
  const profiles = names.map(([full_name, role, stage, email, tags], i) => ({
    id: id("p", i + 1), full_name, role, stage, email, tags, phone: `+971 50 ${100 + i * 7} ${2000 + i * 31}`,
    bio: i === 0 ? "Building things for the local church." : "", created_at: ago(60 * 24 * (30 + i)),
  }));
  const teams = [
    { id: "t-1", name: "Worship", description: "Leading the church in sung worship.", colour: "#C9A96E", leader_id: "p-2" },
    { id: "t-2", name: "Sound and Tech", description: "Audio, slides and livestream.", colour: "#1A2E22", leader_id: "p-3" },
    { id: "t-3", name: "Welcome", description: "The first friendly faces people meet.", colour: "#B23A2F", leader_id: "p-8" },
    { id: "t-4", name: "Kids", description: "Looking after our little ones safely.", colour: "#7A231D", leader_id: "p-5" },
  ];
  const tm = (t: string, p: number, position = "") => ({ team_id: t, person_id: `p-${p}`, position });
  const team_members = [
    tm("t-1", 2, "Leader"), tm("t-1", 4, "Vocals"), tm("t-1", 7, "Keys"), tm("t-1", 12, "Vocals"),
    tm("t-2", 3, "Leader"), tm("t-2", 1, "Livestream"), tm("t-2", 9, "Sound desk"), tm("t-2", 10, "Slides"),
    tm("t-3", 8, "Leader"), tm("t-3", 6, "Greeter"), tm("t-3", 4, "Greeter"), tm("t-3", 11, "Coffee"),
    tm("t-4", 5, "Leader"), tm("t-4", 8, "Helper"), tm("t-4", 10, "Helper"),
  ];
  const services = [0, 1, 2, 3].map((w) => ({
    id: `s-${w + 1}`, title: "Sunday Gathering", starts_at: iso(nextSunday(w)), notes: w === 0 ? "Communion this week." : "",
  }));
  const items: any[] = [];
  const run: [string, string, number, string?][] = [
    ["Welcome and call to worship", "welcome", 5, "p-2"], ["Worship set", "worship", 25, "p-2"], ["Notices", "notices", 5, "p-3"],
    ["Prayer", "prayer", 5, "p-8"], ["Message", "talk", 30, "p-1"], ["Response and ministry", "response", 10], ["Offering and close", "offering", 5],
  ];
  services.forEach((s) => run.forEach(([title, kind, minutes, owner], i) =>
    items.push({ id: `${s.id}-i${i}`, service_id: s.id, sort: i, title, kind, minutes, owner_id: owner ?? null, notes: "" })));
  const slots: any[] = [];
  const roles: [string, string, number[]][] = [
    ["t-1", "Vocals", [4, 12]], ["t-1", "Keys", [7]], ["t-2", "Livestream", [1]], ["t-2", "Sound desk", [9]], ["t-2", "Slides", [10]],
    ["t-3", "Greeter", [6, 11]], ["t-3", "Coffee", [8]], ["t-4", "Kids helper", [5, 3]],
  ];
  services.forEach((s, si) => roles.forEach(([team_id, role_name, ppl], ri) => ppl.forEach((p, k) => {
    const open = si >= 2 && (ri + k) % 3 === 0;
    const status = open ? "pending" : si === 0 && (p === 4 || (ri + k) % 4 === 1) ? "pending" : si === 1 && ri === 2 ? "swap_requested" : "accepted";
    slots.push({ id: `${s.id}-r${ri}-${k}`, service_id: s.id, team_id, role_name, person_id: open ? null : `p-${p}`, status: open ? "pending" : status });
  })));
  const chats = [
    { id: "c-1", name: "Worship team", team_id: "t-1", created_by: "p-2", created_at: ago(5000) },
    { id: "c-2", name: "Sound and Tech", team_id: "t-2", created_by: "p-3", created_at: ago(5000) },
    { id: "c-3", name: "Welcome", team_id: "t-3", created_by: "p-8", created_at: ago(5000) },
    { id: "c-4", name: "Kids", team_id: "t-4", created_by: "p-5", created_at: ago(5000) },
    { id: "c-5", name: "Leaders", team_id: null, created_by: "p-1", created_at: ago(5000) },
  ];
  const chat_members: any[] = [];
  team_members.forEach((m) => { const c = chats.find((c) => c.team_id === m.team_id)!; chat_members.push({ chat_id: c.id, person_id: m.person_id }); });
  [1, 2, 3, 5, 8].forEach((p) => chat_members.push({ chat_id: "c-5", person_id: `p-${p}` }));
  const messages = [
    { id: "m-1", chat_id: "c-1", sender_id: "p-2", body: "Set list is up for Sunday. Please have a listen before Thursday rehearsal.", created_at: ago(300) },
    { id: "m-2", chat_id: "c-1", sender_id: "p-4", body: "Got it, thank you Grace.", created_at: ago(240) },
    { id: "m-3", chat_id: "c-1", sender_id: "p-7", body: "Can we run the bridge in the second song once more?", created_at: ago(120) },
    { id: "m-4", chat_id: "c-2", sender_id: "p-3", body: "Stream test at 9:00 on Sunday, please arrive early.", created_at: ago(900) },
    { id: "m-5", chat_id: "c-5", sender_id: "p-1", body: "Leaders, please confirm your teams for the next four weeks by Friday.", created_at: ago(60) },
  ];
  const posts = [
    { id: "b-1", author_id: "p-1", title: "Welcome to CityGates Hub", body: "This is where we organise serving, share news and keep each other in the loop. Add your blocked dates on your profile so rotas work around you.", category: "announcement", pinned: true, created_at: ago(2000) },
    { id: "b-2", author_id: "p-2", title: "Worship night this Thursday", body: "Open rehearsal followed by a night of worship. Everyone welcome.", category: "event", pinned: false, created_at: ago(900) },
    { id: "b-3", author_id: "p-8", title: "Prayer for exams", body: "Several of our students have exams this month. Please remember them in prayer.", category: "prayer", pinned: false, created_at: ago(400) },
    { id: "b-4", author_id: "p-6", title: "Spare room near Marina", body: "A friend arriving from the UK is looking for a short let. Message me if you can help.", category: "need", pinned: false, created_at: ago(100) },
  ];
  const d = (days: number, h = 19) => { const x = new Date(); x.setDate(x.getDate() + days); x.setHours(h, 0, 0, 0); return iso(x); };
  const events = [
    { id: "e-1", title: "Newcomers lunch", description: "Meet the team over lunch after the service.", location: "Church hall", starts_at: iso(nextSunday(1, 12, 30)), capacity: 30 },
    { id: "e-2", title: "Young adults social", description: "Games, food and conversation.", location: "Jumeirah Beach Park", starts_at: d(6, 18), capacity: 40 },
    { id: "e-3", title: "Serving team training", description: "Safeguarding and welcome basics for all volunteers.", location: "Main auditorium", starts_at: d(12, 19), capacity: null },
  ];
  const event_signups = [{ event_id: "e-1", person_id: "p-6" }, { event_id: "e-1", person_id: "p-11" }, { event_id: "e-2", person_id: "p-4" }];
  const unavailability = [{ id: "u-1", person_id: "p-4", day: iso(nextSunday(1)).slice(0, 10), reason: "Travelling" }];
  return { profiles, teams, team_members, services, service_items: items, rota_slots: slots, chats, chat_members, messages, posts, events, event_signups, attendance: [], unavailability };
}
