import { createClient } from "@supabase/supabase-js";
import { mockClient } from "./mock";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export const DEMO = !url || !key;
export const db: any = DEMO ? mockClient : createClient(url!, key!);
export const auth = DEMO ? null : db.auth;
