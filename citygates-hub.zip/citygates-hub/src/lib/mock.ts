// A tiny in-browser stand-in for the Supabase client, used in DEMO MODE.
// Implements just the calls the app makes. Data lives in localStorage.
import { makeSeed } from "./seed";

const KEY = "cg-hub-demo-v1";
type Row = Record<string, any>;
type DB = Record<string, Row[]>;
const listeners: Record<string, Set<() => void>> = {};

function load(): DB {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  const seed = makeSeed();
  save(seed);
  return seed;
}
function save(db: DB) {
  try { localStorage.setItem(KEY, JSON.stringify(db)); } catch {}
}
function emit(table: string) {
  (listeners[table] || new Set()).forEach((cb) => cb());
}
export function resetDemo() {
  try { localStorage.removeItem(KEY); } catch {}
}
const uuid = () => (globalThis.crypto?.randomUUID?.() ?? Math.random().toString(36).slice(2) + Date.now());

class Query {
  op: "select" | "insert" | "update" | "delete" | "upsert" = "select";
  filters: ((r: Row) => boolean)[] = [];
  payload: any;
  orders: { col: string; asc: boolean }[] = [];
  lim?: number;
  one: "single" | "maybe" | null = null;
  conflict?: string[];
  constructor(private table: string) {}
  select() { return this; }
  insert(p: any) { this.op = "insert"; this.payload = p; return this; }
  update(p: any) { this.op = "update"; this.payload = p; return this; }
  delete() { this.op = "delete"; return this; }
  upsert(p: any, o?: { onConflict?: string }) { this.op = "upsert"; this.payload = p; this.conflict = o?.onConflict?.split(",").map((s) => s.trim()); return this; }
  eq(c: string, v: any) { this.filters.push((r) => r[c] === v); return this; }
  neq(c: string, v: any) { this.filters.push((r) => r[c] !== v); return this; }
  in(c: string, vs: any[]) { this.filters.push((r) => vs.includes(r[c])); return this; }
  gte(c: string, v: any) { this.filters.push((r) => r[c] >= v); return this; }
  order(col: string, o?: { ascending?: boolean }) { this.orders.push({ col, asc: o?.ascending !== false }); return this; }
  limit(n: number) { this.lim = n; return this; }
  single() { this.one = "single"; return this; }
  maybeSingle() { this.one = "maybe"; return this; }
  private run(): { data: any; error: any } {
    const db = load();
    const rows = (db[this.table] ||= []);
    const match = (r: Row) => this.filters.every((f) => f(r));
    let out: Row[] = [];
    if (this.op === "select") out = rows.filter(match);
    else if (this.op === "insert" || this.op === "upsert") {
      const list = Array.isArray(this.payload) ? this.payload : [this.payload];
      for (const p of list) {
        const row = { id: uuid(), created_at: new Date().toISOString(), ...p };
        if (this.op === "upsert" && this.conflict) {
          const i = rows.findIndex((r) => this.conflict!.every((c) => r[c] === row[c]));
          if (i >= 0) { rows[i] = { ...rows[i], ...p }; out.push(rows[i]); continue; }
        }
        rows.push(row); out.push(row);
      }
      save(db); emit(this.table);
    } else if (this.op === "update") {
      rows.forEach((r, i) => { if (match(r)) { rows[i] = { ...r, ...this.payload }; out.push(rows[i]); } });
      save(db); emit(this.table);
    } else if (this.op === "delete") {
      db[this.table] = rows.filter((r) => { const m = match(r); if (m) out.push(r); return !m; });
      save(db); emit(this.table);
    }
    for (const o of [...this.orders].reverse())
      out = [...out].sort((a, b) => (a[o.col] > b[o.col] ? 1 : a[o.col] < b[o.col] ? -1 : 0) * (o.asc ? 1 : -1));
    if (this.lim) out = out.slice(0, this.lim);
    if (this.one) {
      if (!out.length && this.one === "single") return { data: null, error: { message: "No rows" } };
      return { data: out[0] ?? null, error: null };
    }
    return { data: out, error: null };
  }
  then(res: (v: any) => any, rej?: (e: any) => any) {
    return Promise.resolve().then(() => this.run()).then(res, rej);
  }
}

export const mockClient: any = {
  from: (t: string) => new Query(t),
  channel: (_name: string) => {
    const subs: { table: string; cb: () => void }[] = [];
    const ch: any = {
      on: (_e: string, cfg: { table: string }, cb: () => void) => { subs.push({ table: cfg.table, cb }); return ch; },
      subscribe: () => { subs.forEach((s) => (listeners[s.table] ||= new Set()).add(s.cb)); return ch; },
      _off: () => subs.forEach((s) => listeners[s.table]?.delete(s.cb)),
    };
    return ch;
  },
  removeChannel: (ch: any) => ch?._off?.(),
};
