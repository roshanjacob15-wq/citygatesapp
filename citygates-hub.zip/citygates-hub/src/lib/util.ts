export const initials = (n = "") => n.split(/\s+/).filter(Boolean).slice(0, 2).map((s) => s[0]?.toUpperCase()).join("");
export const fmtDate = (iso: string) => new Date(iso).toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });
export const fmtLongDate = (iso: string) => new Date(iso).toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" });
export const fmtTime = (iso: string) => new Date(iso).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
export const fmtAgo = (iso: string) => {
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return fmtDate(iso);
};
export const dayKey = (iso: string) => iso.slice(0, 10);
export const isFuture = (iso: string) => new Date(iso).getTime() > Date.now() - 6 * 3600 * 1000;
export const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(" ");
export const cap = (s = "") => s.charAt(0).toUpperCase() + s.slice(1);
