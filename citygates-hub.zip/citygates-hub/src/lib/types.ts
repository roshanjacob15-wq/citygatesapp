export type Role = "admin" | "leader" | "member";
export type Stage = "visitor" | "regular" | "member" | "leader";
export interface Person {
  id: string; auth_user_id?: string | null; full_name: string; email?: string | null; phone?: string | null;
  bio?: string | null; birthday?: string | null; avatar_url?: string | null;
  stage: Stage; role: Role; tags: string[]; created_at?: string;
}
export interface Team { id: string; name: string; description?: string; colour: string; leader_id?: string | null }
export interface TeamMember { team_id: string; person_id: string; position?: string | null }
export interface Service { id: string; title: string; starts_at: string; notes?: string | null }
export interface ServiceItem { id: string; service_id: string; sort: number; title: string; kind: string; minutes: number; owner_id?: string | null; notes?: string | null }
export interface Slot { id: string; service_id: string; team_id: string; role_name: string; person_id?: string | null; status: "pending" | "accepted" | "declined" | "swap_requested" }
export interface Chat { id: string; name: string; team_id?: string | null; created_by?: string | null; created_at: string }
export interface ChatMember { chat_id: string; person_id: string }
export interface Message { id: string; chat_id: string; sender_id: string; body: string; created_at: string }
export interface Post { id: string; author_id: string; title: string; body?: string; category: string; pinned: boolean; created_at: string }
export interface EventRow { id: string; title: string; description?: string; location?: string; starts_at: string; capacity?: number | null }
export interface Signup { event_id: string; person_id: string }
export interface Attendance { id: string; service_id: string; person_id: string; area: "main" | "kids" | "youth"; guardian_id?: string | null; checked_in_at: string }
export interface Unavail { id: string; person_id: string; day: string; reason?: string }

export const STAGES: Stage[] = ["visitor", "regular", "member", "leader"];
export const SUGGESTED_TAGS = ["Student", "Young professional", "Family", "Single", "New to Dubai", "Prayer partner", "Home group host"];
export const POST_CATEGORIES = [
  { id: "announcement", label: "Announcement" },
  { id: "prayer", label: "Prayer" },
  { id: "need", label: "Needs and offers" },
  { id: "event", label: "Event" },
  { id: "general", label: "General" },
];
export const ITEM_KINDS = ["welcome", "worship", "prayer", "notices", "talk", "response", "offering", "other"];
