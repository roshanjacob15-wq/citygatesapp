import { db } from "./db";
import { write } from "./session";
import type { Slot } from "./types";

export const respond = (id: string, status: Slot["status"]) =>
  write(db.from("rota_slots").update({ status }).eq("id", id),
    status === "accepted" ? "Thank you, you're confirmed." : status === "declined" ? "Declined. Your leader has been told." : status === "swap_requested" ? "Swap requested. Others on the team can pick it up." : undefined);

export const claim = (id: string, personId: string) =>
  write(db.from("rota_slots").update({ person_id: personId, status: "accepted" }).eq("id", id), "Slot claimed. Thank you!");

export const statusTone = (s: string): "gold" | "green" | "red" | "plain" =>
  s === "accepted" ? "green" : s === "declined" ? "red" : s === "swap_requested" ? "gold" : "plain";
export const statusLabel = (s: string) =>
  ({ pending: "Awaiting reply", accepted: "Confirmed", declined: "Declined", swap_requested: "Swap needed" } as any)[s] ?? s;
