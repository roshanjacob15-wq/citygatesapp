"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { db, auth, DEMO } from "./db";
import { resetDemo } from "./mock";
import type { Person, Team, TeamMember } from "./types";

interface Ctx {
  ready: boolean;
  me: Person | null;
  people: Person[];
  teams: Team[];
  teamMembers: TeamMember[];
  isLeader: boolean;
  isAdmin: boolean;
  refresh: () => Promise<void>;
  person: (id?: string | null) => Person | undefined;
  signOut: () => Promise<void>;
  switchDemoUser: (id: string) => void;
  resetDemoData: () => void;
}
const C = createContext<Ctx>(null as any);
export const useSession = () => useContext(C);

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [me, setMe] = useState<Person | null>(null);
  const [people, setPeople] = useState<Person[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [teamMembers, setTM] = useState<TeamMember[]>([]);

  const refresh = useCallback(async () => {
    let myId: string | null = null;
    if (DEMO) {
      myId = localStorage.getItem("cg-demo-user") || "p-1";
    } else {
      const { data } = await auth.getSession();
      const uid = data?.session?.user?.id;
      if (!uid) { setMe(null); setPeople([]); setReady(true); return; }
      const { data: mine } = await db.from("profiles").select("*").eq("auth_user_id", uid).maybeSingle();
      myId = mine?.id ?? null;
    }
    const [p, t, tm] = await Promise.all([
      db.from("profiles").select("*").order("full_name"),
      db.from("teams").select("*").order("name"),
      db.from("team_members").select("*"),
    ]);
    const all: Person[] = p.data ?? [];
    setPeople(all);
    setTeams(t.data ?? []);
    setTM(tm.data ?? []);
    setMe(all.find((x) => x.id === myId) ?? null);
    setReady(true);
  }, []);

  useEffect(() => {
    refresh();
    if (!DEMO) {
      const { data } = auth.onAuthStateChange(() => refresh());
      return () => data.subscription.unsubscribe();
    }
  }, [refresh]);

  const value = useMemo<Ctx>(() => ({
    ready, me, people, teams, teamMembers,
    isLeader: me?.role === "admin" || me?.role === "leader",
    isAdmin: me?.role === "admin",
    refresh,
    person: (id) => people.find((x) => x.id === id),
    signOut: async () => { if (!DEMO) await auth.signOut(); setMe(null); },
    switchDemoUser: (id) => { localStorage.setItem("cg-demo-user", id); refresh(); },
    resetDemoData: () => { resetDemo(); localStorage.removeItem("cg-demo-user"); location.href = "/"; },
  }), [ready, me, people, teams, teamMembers, refresh]);

  return <C.Provider value={value}>{children}</C.Provider>;
}

// ---- data hooks --------------------------------------------------------
export function useRows<T = any>(table: string, order?: [string, boolean]) {
  const [rows, setRows] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const reload = useCallback(async () => {
    let q = db.from(table).select("*");
    if (order) q = q.order(order[0], { ascending: order[1] });
    const { data } = await q;
    setRows(data ?? []);
    setLoading(false);
  }, [table, order?.[0], order?.[1]]);
  useEffect(() => {
    reload();
    const ch = db.channel(`rows-${table}-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "*", schema: "public", table }, () => reload())
      .subscribe();
    return () => { db.removeChannel(ch); };
  }, [reload, table]);
  return { rows, loading, reload };
}

// ---- toast + guarded writes -------------------------------------------
export function toast(msg: string) {
  window.dispatchEvent(new CustomEvent("cg-toast", { detail: msg }));
}
/** Await a write, show a friendly error if it fails. Returns data or null. */
export async function write<T = any>(p: PromiseLike<{ data: T; error: any }>, ok?: string): Promise<T | null> {
  const { data, error } = await p;
  if (error) { toast(error.message || "Something went wrong"); return null; }
  if (ok) toast(ok);
  return (data ?? ([] as any)) as T;
}
