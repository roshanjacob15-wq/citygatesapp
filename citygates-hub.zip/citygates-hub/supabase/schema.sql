-- CityGates Hub — database schema. Run once in the Supabase SQL editor.
create extension if not exists "pgcrypto";

-- PEOPLE ---------------------------------------------------------------
create table profiles (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid unique references auth.users(id) on delete set null,
  full_name text not null,
  email text unique,
  phone text,
  bio text,
  birthday date,
  avatar_url text,
  stage text not null default 'visitor' check (stage in ('visitor','regular','member','leader')),
  role text not null default 'member' check (role in ('admin','leader','member')),
  tags text[] not null default '{}',
  created_at timestamptz not null default now()
);

create table unavailability (
  id uuid primary key default gen_random_uuid(),
  person_id uuid not null references profiles(id) on delete cascade,
  day date not null,
  reason text,
  unique (person_id, day)
);

-- TEAMS ----------------------------------------------------------------
create table teams (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  colour text not null default '#C9A96E',
  leader_id uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create table team_members (
  team_id uuid references teams(id) on delete cascade,
  person_id uuid references profiles(id) on delete cascade,
  position text,
  primary key (team_id, person_id)
);

-- SERVICES, RUN SHEET, ROTA -------------------------------------------
create table services (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  starts_at timestamptz not null,
  notes text,
  created_at timestamptz not null default now()
);
create table service_items (
  id uuid primary key default gen_random_uuid(),
  service_id uuid not null references services(id) on delete cascade,
  sort int not null default 0,
  title text not null,
  kind text not null default 'other',
  minutes int not null default 5,
  owner_id uuid references profiles(id) on delete set null,
  notes text
);
create table rota_slots (
  id uuid primary key default gen_random_uuid(),
  service_id uuid not null references services(id) on delete cascade,
  team_id uuid not null references teams(id) on delete cascade,
  role_name text not null,
  person_id uuid references profiles(id) on delete set null,
  status text not null default 'pending' check (status in ('pending','accepted','declined','swap_requested')),
  created_at timestamptz not null default now()
);

-- CHAT -----------------------------------------------------------------
create table chats (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  team_id uuid references teams(id) on delete cascade,
  created_by uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create table chat_members (
  chat_id uuid references chats(id) on delete cascade,
  person_id uuid references profiles(id) on delete cascade,
  primary key (chat_id, person_id)
);
create table messages (
  id uuid primary key default gen_random_uuid(),
  chat_id uuid not null references chats(id) on delete cascade,
  sender_id uuid references profiles(id) on delete set null,
  body text not null,
  created_at timestamptz not null default now()
);

-- BULLETIN BOARD -------------------------------------------------------
create table posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid references profiles(id) on delete set null,
  title text not null,
  body text,
  category text not null default 'announcement',
  pinned boolean not null default false,
  created_at timestamptz not null default now()
);

-- EVENTS ---------------------------------------------------------------
create table events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  location text,
  starts_at timestamptz not null,
  capacity int,
  created_at timestamptz not null default now()
);
create table event_signups (
  event_id uuid references events(id) on delete cascade,
  person_id uuid references profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (event_id, person_id)
);

-- ATTENDANCE / CHECK-IN -----------------------------------------------
create table attendance (
  id uuid primary key default gen_random_uuid(),
  service_id uuid not null references services(id) on delete cascade,
  person_id uuid not null references profiles(id) on delete cascade,
  area text not null default 'main' check (area in ('main','kids','youth')),
  guardian_id uuid references profiles(id) on delete set null,
  checked_in_at timestamptz not null default now(),
  unique (service_id, person_id)
);

-- AUTH LINKING: when someone signs in by magic link, attach them to the
-- profile an admin created for their email (or create a fresh member profile).
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update profiles set auth_user_id = new.id
    where lower(email) = lower(new.email) and auth_user_id is null;
  if not found then
    insert into profiles (auth_user_id, full_name, email, role)
    values (new.id, split_part(new.email,'@',1), new.email,
            case when (select count(*) from profiles) = 0 then 'admin' else 'member' end);
  end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- HELPERS ---------------------------------------------------------------
create or replace function me() returns uuid language sql stable security definer set search_path = public as
$$ select id from profiles where auth_user_id = auth.uid() $$;
create or replace function my_role() returns text language sql stable security definer set search_path = public as
$$ select role from profiles where auth_user_id = auth.uid() $$;
create or replace function is_leader() returns boolean language sql stable as
$$ select coalesce(my_role() in ('admin','leader'), false) $$;
create or replace function is_admin() returns boolean language sql stable as
$$ select coalesce(my_role() = 'admin', false) $$;
create or replace function in_chat(c uuid) returns boolean language sql stable security definer set search_path = public as
$$ select is_admin() or exists (select 1 from chat_members where chat_id = c and person_id = me()) $$;

-- ROW LEVEL SECURITY ----------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array['profiles','unavailability','teams','team_members','services','service_items',
    'rota_slots','chats','chat_members','messages','posts','events','event_signups','attendance']
  loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy "read_%1$s" on %1$I for select to authenticated using (true)', t);
  end loop;
end $$;

-- profiles: leaders manage people; everyone edits their own row (but not role)
create policy profiles_insert on profiles for insert to authenticated with check (is_leader());
create policy profiles_update on profiles for update to authenticated
  using (is_leader() or id = me())
  with check (is_admin() or is_leader() and role <> 'admin' or id = me() and role = (select role from profiles where id = me()));
create policy profiles_delete on profiles for delete to authenticated using (is_admin());

create policy unavail_all on unavailability for all to authenticated
  using (person_id = me() or is_leader()) with check (person_id = me() or is_leader());

-- teams, services, run sheet: leaders manage
create policy teams_w on teams for all to authenticated using (is_leader()) with check (is_leader());
create policy team_members_w on team_members for all to authenticated using (is_leader()) with check (is_leader());
create policy services_w on services for all to authenticated using (is_leader()) with check (is_leader());
create policy service_items_w on service_items for all to authenticated using (is_leader()) with check (is_leader());

-- rota: leaders manage; members may respond to their own slot or claim a swap
create policy slots_leader on rota_slots for all to authenticated using (is_leader()) with check (is_leader());
create policy slots_respond on rota_slots for update to authenticated
  using (person_id = me() or status = 'swap_requested') with check (person_id = me());

-- chat: only members (or admins) read/post
drop policy read_chats on chats;
create policy chats_read on chats for select to authenticated using (in_chat(id));
create policy chats_insert on chats for insert to authenticated with check (is_leader());
create policy chats_update on chats for update to authenticated using (is_leader());
create policy chats_delete on chats for delete to authenticated using (is_leader());
create policy chat_members_w on chat_members for all to authenticated using (is_leader()) with check (is_leader());
drop policy read_messages on messages;
create policy messages_read on messages for select to authenticated using (in_chat(chat_id));
create policy messages_insert on messages for insert to authenticated with check (sender_id = me() and in_chat(chat_id));
create policy messages_delete on messages for delete to authenticated using (sender_id = me() or is_leader());

-- board: everyone posts; authors and leaders edit
create policy posts_insert on posts for insert to authenticated with check (author_id = me());
create policy posts_update on posts for update to authenticated using (author_id = me() or is_leader());
create policy posts_delete on posts for delete to authenticated using (author_id = me() or is_leader());

-- events
create policy events_w on events for all to authenticated using (is_leader()) with check (is_leader());
create policy signups_w on event_signups for all to authenticated
  using (person_id = me() or is_leader()) with check (person_id = me() or is_leader());

-- attendance: leaders check people in
create policy attendance_w on attendance for all to authenticated using (is_leader()) with check (is_leader());

-- realtime for chat + board
alter publication supabase_realtime add table messages, posts, rota_slots;
